<?php
/*
Plugin Name: WP Multiple Datepicker
Description: A custom plugin to select multiple dates per month and show them highlighted in the frontend calendar.
Version: 1.0
Author: Your Name
License: GPL2
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define paths
define('WP_MULTIPLE_DATEPICKER_PATH', plugin_dir_path(__FILE__));
define('WP_MULTIPLE_DATEPICKER_URL', plugin_dir_url(__FILE__));

// Include admin menu and functions
require_once WP_MULTIPLE_DATEPICKER_PATH . 'admin/admin-menu.php';
require_once WP_MULTIPLE_DATEPICKER_PATH . 'includes/save-dates.php';

// Include front-end functions
require_once WP_MULTIPLE_DATEPICKER_PATH . 'templates/calendar.php';

function load_fullcalendar_assets() {
    wp_enqueue_script('moment-js', 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js', array(), null, true);
    wp_enqueue_script('jquery');

    // FullCalendar
    wp_enqueue_style('fullcalendar-css', 'https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.2.0/fullcalendar.min.css');
    wp_enqueue_script('fullcalendar-js', 'https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.2.0/fullcalendar.min.js', array('jquery'), null, true);

    // Tippy.js and Popper.js
    
    wp_enqueue_script('popper-js', 'https://unpkg.com/@popperjs/core@2', array(), null, true);
    wp_enqueue_script('tippy-js', 'https://unpkg.com/tippy.js@6', array('popper-js'), null, true);
    wp_enqueue_style('tippy-css', 'https://unpkg.com/tippy.js@6/themes/light.css');
}
add_action('wp_enqueue_scripts', 'load_fullcalendar_assets');
function wp_enqueue_calendar_assets() {
    if ( is_singular() || is_page() || is_front_page() ) {
        wp_enqueue_script(
            'calendar-tooltip',
            plugin_dir_url(__FILE__) . 'assets/calendar-tooltip.js',
            ['jquery'],
            '1.0',
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'wp_enqueue_calendar_assets');


