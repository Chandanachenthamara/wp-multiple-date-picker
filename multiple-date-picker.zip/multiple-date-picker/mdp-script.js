<?php
/**
 * Plugin Name: Multiple Datepicker Admin
 * Description: Adds a menu in WP Admin with datepickers for each month and displays selected dates on the frontend.
 * Version: 1.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Register Admin Menu
function mdp_add_admin_menu() {
    add_menu_page('Multiple Datepicker', 'Multiple Datepicker', 'manage_options', 'multiple-datepicker', 'mdp_admin_page');
}
add_action('admin_menu', 'mdp_add_admin_menu');

// Admin Page Content
function mdp_admin_page() {
    ?>
    <div class="wrap">
        <h1>Select Dates for Each Month</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('mdp_settings_group');
            do_settings_sections('multiple-datepicker');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register Settings
function mdp_register_settings() {
    for ($i = 1; $i <= 12; $i++) {
        $month = date('F', mktime(0, 0, 0, $i, 10));
        register_setting('mdp_settings_group', 'mdp_dates_' . $i);
        add_settings_section('mdp_section_' . $i, __($month, 'mdp'), null, 'multiple-datepicker');
        add_settings_field('mdp_field_' . $i, __('Select Dates', 'mdp'), 'mdp_datepicker_callback', 'multiple-datepicker', 'mdp_section_' . $i, ['month' => $i]);
    }
}
add_action('admin_init', 'mdp_register_settings');

// Datepicker Callback
function mdp_datepicker_callback($args) {
    $month = $args['month'];
    $selected_dates = get_option('mdp_dates_' . $month, '');
    ?>
    <input type="text" class="mdp-datepicker" name="mdp_dates_<?php echo $month; ?>" value="<?php echo esc_attr($selected_dates); ?>">
    <?php
}

// Load jQuery UI Datepicker
function mdp_admin_scripts($hook) {
    if ($hook !== 'toplevel_page_multiple-datepicker') return;
    wp_enqueue_script('jquery-ui-datepicker');
    wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css');
    wp_enqueue_script('mdp-script', plugin_dir_url(__FILE__) . 'mdp-script.js', ['jquery', 'jquery-ui-datepicker'], null, true);
}
add_action('admin_enqueue_scripts', 'mdp_admin_scripts');

// // Frontend Shortcode
// function mdp_display_dates() {
//     $output = '<h3>Selected Dates</h3><ul>';
//     for ($i = 1; $i <= 12; $i++) {
//         $dates = get_option('mdp_dates_' . $i, '');
//         if ($dates) {
//             $output .= '<li><strong>' . date('F', mktime(0, 0, 0, $i, 10)) . ':</strong> ' . esc_html($dates) . '</li>';
//         }
//     }
//     $output .= '</ul>';
//     return $output;
// }
// add_shortcode('show_dates', 'mdp_display_dates');




?>




