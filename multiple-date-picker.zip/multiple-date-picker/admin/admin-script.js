jQuery(document).ready(function ($) {
    $(".datepicker").each(function (index) {
        var $input = $(this);
        var selectedDates = $input.val() ? $input.val().split(", ") : [];

        // Set default month dynamically based on input field index
        var defaultMonth = index;
        var defaultYear = new Date().getFullYear(); // Current Year

        $input.datepicker({
            dateFormat: "yy-mm-dd",
            beforeShowDay: function (date) {
                var dateString = $.datepicker.formatDate("yy-mm-dd", date);
                return [true, selectedDates.includes(dateString) ? "selected-date" : ""];
            },
            onSelect: function (dateText) {
                var index = selectedDates.indexOf(dateText);
                if (index > -1) {
                    selectedDates.splice(index, 1); // Remove if already selected
                } else {
                    selectedDates.push(dateText); // Add if not already selected
                }
                $input.val(selectedDates.join(", "));
            },
            beforeShow: function () {
                // Set the correct month when clicking on an input field
                $(this).datepicker("option", "defaultDate", new Date(defaultYear, defaultMonth, 1));
            }
        });
    });

    $("#multiple-datepicker-form").on("submit", function (e) {
    e.preventDefault();

    // Collect the selected dates from each input field
    var formData = [];
    $(".datepicker").each(function (index) {
        var fieldName = $(this).attr("name");
        var selectedDates = $(this).val();
        formData.push({
            month: index,
            dates: selectedDates
        });
    });

    // Collect nonce value from the form
    var nonceValue = $("#wp_multiple_datepicker_nonce_field").val();

    // Save selected dates via AJAX
    $.post(ajaxurl, {
        action: "save_multiple_dates",
        selected_dates: JSON.stringify(formData),
        security: nonceValue // Include the nonce in the request
    }, function (response) {
        if (response.success) {
            alert("Dates saved successfully!");
        } else {
            alert("Error saving dates: " + response.data.message);
        }
    });
});
});


