<?php
if (!defined('ABSPATH')) {
    exit;
}

function wp_multiple_datepicker_admin_menu() {
    add_menu_page(
        'Multiple Date Picker',
        'Date Picker',
        'manage_options',
        'wp-multiple-datepicker',
        'wp_multiple_datepicker_admin_page',
        'dashicons-calendar-alt',
        20
    );
}
add_action('admin_menu', 'wp_multiple_datepicker_admin_menu');

function wp_multiple_datepicker_admin_page() {
    // Check if the form is submitted
   if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dates'])) {
    // Save the dates to the options table
    foreach ($_POST['dates'] as $index => $date) {
        update_option("wp_multiple_dates_{$index}", sanitize_text_field($date));
    }
    echo '<div class="updated"><p>Dates saved successfully!</p></div>';
}

    

    ?>
    <div class="wrap-multi">
        <h2>Select Dates for Each Month</h2>
       <form id="multiple-datepicker-form" method="POST">
    <?php wp_nonce_field('wp_multiple_datepicker_nonce_field', 'wp_multiple_datepicker_nonce_field'); ?>
    <?php
    $months = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
    foreach ($months as $index => $month) {
        $saved_date = get_option("wp_multiple_dates_{$index}", '');
        echo "<label for='dates_{$index}'>$month:</label>";
        echo "<input type='text' id='dates_{$index}' class='datepicker' name='dates[{$index}]' value='" . esc_attr($saved_date) . "' />";
        echo "<br/>";
    }
    ?>
    <button type="submit" class="button button-primary">Save Dates</button>
</form>
    </div>
    <?php
}

// Enqueue Admin Scripts and Styles
function wp_multiple_datepicker_admin_scripts() {
    wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css');
    wp_enqueue_script('jquery-ui-datepicker');
    wp_enqueue_script('wp-multiple-datepicker-admin-script', WP_MULTIPLE_DATEPICKER_URL . 'admin/admin-script.js', array('jquery', 'jquery-ui-datepicker'), null, true);
    wp_enqueue_style('wp-multiple-datepicker-admin-style', WP_MULTIPLE_DATEPICKER_URL . 'admin/admin-style.css');
	
}
add_action('admin_enqueue_scripts', 'wp_multiple_datepicker_admin_scripts');



