document.addEventListener("DOMContentLoaded", function() {
    var calendarEl = document.getElementById("calendar");

    console.log('Calendar element:', Calendar);

    
    if (typeof FullCalendar !== 'undefined' && typeof FullCalendar.Calendar !== 'undefined') {
        // Check if the calendar element exists
      if (calendarEl) {
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: "dayGridMonth", // Month view
            events: eventsData // Use the events passed from PHP
        });
            calendar.render(); // Render the calendar
            console.log('FullCalendar initialized successfully!');
        } else {
            console.log('Calendar element not found!');
        }
    } else {
        console.log('FullCalendar is not loaded properly.');
    }
});




