<?php
if (!defined('ABSPATH')) {
    exit;
}function save_multiple_dates() {
    // Verify nonce
    if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'wp_multiple_datepicker_nonce_field')) {
        wp_send_json_error('Nonce verification failed');
        return;
    }

    if (!isset($_POST['selected_dates'])) {
        wp_send_json_error('No dates received');
        return;
    }

    $selected_dates = json_decode(stripslashes($_POST['selected_dates']), true);

    if (!is_array($selected_dates)) {
        wp_send_json_error('Invalid data format');
        return;
    }

    foreach ($selected_dates as $month_data) {
        $month_index = intval($month_data['month']);
        $dates = array_map('sanitize_text_field', explode(", ", $month_data['dates']));
        update_option("wp_multiple_dates_{$month_index}", implode(", ", $dates));
    }

    wp_send_json_success('Dates saved successfully');
}

add_action('wp_ajax_save_multiple_dates', 'save_multiple_dates');
add_action('wp_ajax_nopriv_save_multiple_dates', 'save_multiple_dates'); // Allow non-logged-in users if needed


