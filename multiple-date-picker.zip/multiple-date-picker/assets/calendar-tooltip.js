jQuery(window).on("elementor/frontend/init", function () {
    elementorFrontend.hooks.addAction("frontend/element_ready/global", function ($scope, $) {
        if (document.getElementById("calendar")) {
            initCalendarHover();
        }
    });
});

function initCalendarHover() {
    const calendarContainer = document.getElementById("calendar");
    if (!calendarContainer) return;

    const selectedDates = JSON.parse(calendarContainer.dataset.dates || "[]");
    const eventDescriptions = JSON.parse(calendarContainer.dataset.descriptions || "{}");

    const today = new Date();
    const month = today.getMonth();
    const year = today.getFullYear();

    const tooltip = document.createElement("div");
    tooltip.className = "custom-tooltip";
    document.body.appendChild(tooltip);

    const renderCalendar = (y, m) => {
        const daysInMonth = new Date(y, m + 1, 0).getDate();
        const firstDay = new Date(y, m, 1).getDay();
        const monthName = new Date(y, m).toLocaleString("default", { month: "long" });

        let calendarHTML = `<h3>${monthName} ${y}</h3>
            <table class="calendar-table">
            <thead><tr>
                <th>Sun</th><th>Mon</th><th>Tue</th>
                <th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
            </tr></thead><tbody><tr>`;

        for (let i = 0; i < firstDay; i++) {
            calendarHTML += "<td></td>";
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const formattedDate = `${y}-${String(m + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
            const isHighlighted = selectedDates.includes(formattedDate) ? "highlighted" : "";
            const hasDescription = eventDescriptions[formattedDate] ? "has-description" : "";

            const dateObj = new Date(formattedDate);
            const isPast = dateObj < new Date().setHours(0, 0, 0, 0);
            const expiredClass = isPast && eventDescriptions[formattedDate] ? "expired-date" : "";

            calendarHTML += `<td class="${isHighlighted} ${hasDescription} ${expiredClass}" data-date="${formattedDate}">${day}</td>`;

            if ((day + firstDay) % 7 === 0) {
                calendarHTML += "</tr><tr>";
            }
        }

        calendarHTML += "</tr></tbody></table>";
        calendarContainer.innerHTML = calendarHTML;

        // Tooltip Events
        document.querySelectorAll(".has-description").forEach(cell => {
            cell.addEventListener("mouseover", (e) => {
                const date = e.currentTarget.dataset.date;
                const data = eventDescriptions[date] || {};
                const description = data.description || "";
                const type = data.type || "";
                const hoverDate = new Date(date);
                const isPast = hoverDate < new Date().setHours(0, 0, 0, 0);

                const formatted = hoverDate.toLocaleDateString("default", {
                    day: "numeric", month: "long", year: "numeric"
                });

                tooltip.innerHTML = `
                    <strong>${formatted}${isPast ? " " : ""}</strong>
                    ${type ? `<div><em>${type}</em></div>` : ""}
                    <div style="margin-top:8px;">${description}</div>
                `;

                tooltip.style.display = "block";
            });

            cell.addEventListener("mousemove", (e) => {
                tooltip.style.left = e.pageX + 15 + "px";
                tooltip.style.top = e.pageY + 15 + "px";
            });

            cell.addEventListener("mouseleave", () => {
                tooltip.style.display = "none";
            });

            cell.addEventListener("click", () => {
                const date = cell.dataset.date;
                const targetId = "event_" + date.replaceAll("-", "_");
                const eventEl = document.getElementById(targetId);
                if (eventEl) {
                    document.querySelectorAll(".event-item").forEach(item => {
                        item.style.backgroundColor = "#fff";
                    });

                    eventEl.scrollIntoView({ behavior: "smooth", block: "center" });
                    eventEl.style.backgroundColor = "rgb(144 175 203)";
                }
            });
        });
    };

    renderCalendar(year, month);
}

