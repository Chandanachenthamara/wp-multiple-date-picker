<?php
if (!defined('ABSPATH')) exit;

function wp_display_calendar() {
    $current_month = date('n'); // 1–12

    // Get correct option key
    $option_name = ($current_month == 1) ? "wp_multiple_dates" : "wp_multiple_dates_" . ($current_month - 1);

    // Get selected dates from options
    $selected_dates = get_option($option_name, []);
    if (!is_array($selected_dates)) {
        $selected_dates = array_map('trim', explode(',', $selected_dates));
    }
// Prepare event descriptions from custom post type
$event_descriptions = [];
$event_query = new WP_Query([
    'post_type' => 'calendar_tasks',
    'posts_per_page' => -1,
    'meta_key' => 'event_date',
    'orderby' => 'meta_value',
    'order' => 'ASC'
]);

if ($event_query->have_posts()) {
    while ($event_query->have_posts()) {
        $event_query->the_post();

        $event_date_raw = get_post_meta(get_the_ID(), 'event_date', true);
        $event_description = get_post_meta(get_the_ID(), 'event_description', true);
		$event_type = get_post_meta(get_the_ID(), 'event_type', true);


       if ($event_date_raw && $event_description) {
    $formatted_date = DateTime::createFromFormat('Ymd', $event_date_raw)->format('Y-m-d');
    $event_descriptions[$formatted_date] = [
        'description' => $event_description,
        'type' => $event_type,
    ];
}

    }
    wp_reset_postdata();
}

echo '<div class="calendar-wrapper">';
echo '<div id="calendar" class="calendar-box" 
    data-dates=\'' . json_encode($selected_dates) . '\' 
    data-descriptions=\'' . json_encode($event_descriptions, JSON_HEX_APOS | JSON_HEX_QUOT) . '\'>
</div>';
// print_r($event_descriptions);
echo '<div id="event-list" class="event-box"> 
<h3></h3>';
$has_events = false;
$today = new DateTime('today');

foreach ($event_descriptions as $raw_date => $data) {
    $timestamp = DateTime::createFromFormat('Y-m-d', $raw_date);
    if (!$timestamp) continue;

    if ($timestamp >= $today) {
        $formatted = $timestamp->format("F j, Y");
$desc = wp_kses_post($data['description']);
        $type = !empty($data['type']) ? '<em>' . esc_html($data['type']) . '</em>' : '';
        $sanitized_id = 'event_' . str_replace('-', '_', $raw_date);

        echo "<div class='event-item' id='{$sanitized_id}'>
                <button class='accordion-toggle'>{$formatted} – {$type}</button>
                <div class='accordion-content'>
                    <p>{$desc}</p>
                </div>
              </div>";

        $has_events = true;
    }
}


if (!$has_events) echo "<p>Expired – No Data</p>";
echo '</div>';
echo '</div>'; 



    // Styling
    echo '<style>
        #calendar {
            max-width: 100%;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
		.calendar-wrapper {
    display: flex;
    gap: 30px;
    flex-wrap: wrap;
    justify-content: space-between;
    margin-top: 30px;
}

.calendar-box, .event-box {
    flex: 1 1 48%;
    min-width: 320px;
}

.event-box {
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 1px 6px rgba(0,0,0,0.1);
}

.event-box h3 {
    font-size: 20px;
    margin-bottom: 15px;
    color: #1d4c78;
}

.event-item {
    background-color: #fff;
    padding: 12px 16px;
    margin-bottom: 12px;
    border-left: 4px solid #0F4372;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.event-item strong {
    display: block;
    color: #222;
    margin-bottom: 5px;
}

@media (max-width: 768px) {
    .calendar-wrapper {
        flex-direction: column;
    }
}

        .calendar-table {
            width: 100%;
            border-collapse: collapse;
        }
        .calendar-table th, .calendar-table td {
            width: 14.28%;
            height: 80px;
            border: 1px solid #ccc;
            text-align: center;
            vertical-align: middle;
            position: relative;
        }
        .highlighted {
            background-color: #0F4372 !important;
            color: #fff;
            font-weight: bold;
        }
        .has-description {
            cursor: pointer;
        }
      .custom-tooltip {
    position: absolute;
    background: #0F4372;
    color: white;
    padding: 12px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 14px;
    max-width: 300px;
    line-height: 1.5em;
    pointer-events: none;
    display: none;
    z-index: 9999;
}
.event-item {
    transition: background-color 0.3s ease;
}
   .custom-tooltip {
        position: absolute;
        background-color: #003366; /* Dark blue */
        color: #fff;
        padding: 10px;
        border-radius: 6px;
        font-size: 14px;
        z-index: 1000;
        display: none;
        max-width: 250px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }

    .expired-date {
        background-color: #ffe6e6 !important; /* Light red for expired cells */
        color: #a94442 !important;
        font-weight: bold;
    }

    td.expired-date:hover {
        background-color: #fdd !important;
    }
#calendar {
    max-width: 100%;
    margin: 0 auto;
    padding: 10px;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

.calendar-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
}

.calendar-table th,
.calendar-table td {
    border: 1px solid #ccc;
    text-align: center;
    padding: 8px;
    word-wrap: break-word;
    position: relative;
    font-size: 14px;
}

.calendar-table td.highlighted {
    background-color: #fffae6;
}

.calendar-table td.has-description {
    cursor: pointer;
    background-color: #d6f0ff;
}

.calendar-table td.expired-date {
    background-color: #f8d7da;
    color: #a94442;
}

.custom-tooltip {
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    color: #fff;
    padding: 10px;
    border-radius: 6px;
    font-size: 13px;
    max-width: 200px;
    z-index: 1000;
    display: none;
    pointer-events: none;
}

/* Responsive behavior */
@media (max-width: 768px) {
    .calendar-table th,
    .calendar-table td {
        font-size: 12px;
        padding: 6px 4px;
    }

    .custom-tooltip {
        font-size: 12px;
        max-width: 150px;
    }
}
.accordion-toggle {
    background-color: #0f4372;
    border: none;
    cursor: pointer;
    padding: 12px;
    width: 100%;
    text-align: left;
    font-size: 16px;
    border-bottom: 1px solid #ddd;
    transition: background-color 0.3s ease;
}

.accordion-toggle.active, .accordion-toggle:hover {
    background-color: #0f4372;
}

.accordion-content {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
    background-color: #fafafa;
    padding: 0 12px;
}

.accordion-content p {
    margin: 12px 0;
}

@media (max-width: 480px) {
    .calendar-table th,
    .calendar-table td {
        font-size: 11px;
        padding: 5px 3px;
    }

    #calendar h3 {
        font-size: 18px;
        text-align: center;
    }
}
    </style>';

    // JavaScript
   echo '<script>
jQuery(window).on("elementor/frontend/init", function () {
    elementorFrontend.hooks.addAction("frontend/element_ready/global", function ($scope, $) {
        if (document.getElementById("calendar")) {
            initCalendarHover();
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".accordion-toggle").forEach((toggle) => {
        toggle.addEventListener("click", function () {
            this.classList.toggle("active");
            const content = this.nextElementSibling;
            if (content.style.maxHeight) {
                content.style.maxHeight = null;
            } else {
                content.style.maxHeight = content.scrollHeight + "px";
            }
        });
    });
});

</script>';

}
add_shortcode('wp_multiple_datepicker', 'wp_display_calendar');


